#include<iostream>
using namespace std;
void print(int arr[],int size){
    for(int i=0;i<size;i++){
        cout<<arr[i]<<" ";

    }
}
bool linearsearch(int arr[],int size,int key){
    //base case (recursion)
    print(arr,size);
    cout<<endl;
    cout<<endl;
    if(size==0){
        return false;
    }
    if(arr[0]==key){
        return true;
    }
    else{
        return linearsearch(arr+1,size-1,key);
    }
}
int main(){
    int arr[10]={4,6,9,11,23,46,49,51,55,77};
    int size=10;
    int key=51;
    bool ans=linearsearch(arr,size,key);
    if(ans==true){
        cout<<"Element found"<<endl;
    }
    else{
        cout<<"Element not found!!!"<<endl;
    }

}